﻿Public Class Form1

    Dim num1 As String
    Dim num2 As String
    Dim i As Integer
    Dim x As Integer
    Dim y As Integer
    Dim turn As Integer
    Dim is_win As Integer

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        num1 = CStr(TextBox1.Text)
        num2 = CStr(TextBox2.Text)
        i = 0
        x = 0
        y = 0
        turn = 0
        Do While (i < 20)
            If (ListBox1.Items(i) = num1) Then
                x = x + 1
            End If
            If (ListBox1.Items(i) = num2) Then
                y = y + 1
            End If
            i = i + 1
        Loop
        If x <> 0 And y <> 0 Then
            If num1 - num2 = 1 Or num2 - num1 = 1 Then
                ListBox1.Items(num1 - 1) = "X"
                ListBox1.Items(num2 - 1) = "X"
                turn = turn + 1
            Else
                MsgBox("wrong Tokens ", MsgBoxStyle.RetryCancel,AcceptButton)
            End If

        ElseIf x <> 0 And y = 0 Then
            ListBox1.Items(num1 - 1) = "X"
            turn = turn + 1
        ElseIf x = 0 And y <> 0 Then
            ListBox1.Items(num2 - 1) = "X"
            turn = turn + 1
        Else
            MsgBox("wrong Tokens ", MsgBoxStyle.RetryCancel, AcceptButton)

        End If
        is_win = 0
        i = 0
        Do While (i < 20)
            If ListBox1.Items(i) <> "X" Then
                is_win = is_win + 1
            End If
            i = i + 1
        Loop

        If is_win = 0 Then
            MsgBox("Congratulation you win :D ",MsgBoxStyle.OkOnly)
        Else
            If nturn.Text = "Player 1" And turn <> 0 Then
                nturn.Text = "Player 2"
            ElseIf nturn.Text = "Player 2" And turn <> 0 Then
                nturn.Text = "Player 1"
            End If
            TextBox1.Clear()
            TextBox2.Clear()
        End If


    End Sub
End Class
